RestDoor: Command-Line Java App
====================================

## Project Libraries
This project was compiled and executed with the IntelliJ IDE along with the Gradle build automation tool. It uses the Java client for the Google Maps Services APIs.
The repository for the Google Maps Services Java Client can be found at https://github.com/googlemaps/google-maps-services-java.

## Project Structure
The main source code files are located in src/main/java.
The tests for each module are located in src/test/java.

### src/main/java
- APIWrapper.java: contains the implementation of the API Wrapper responsible for calling the Google Maps Services APIs.
- AppManager.java: contains the implementation of the App Manager that interacts with the database manager and the API Wrapper to fulfill use cases.
- DatabaseManager.java: contains the implementation of the module that interacts directly with the database.
- Restaurant.java: A simple class representing a restaurant object.
- RestDoorCommandLine.java: The driver program that runs the command line application and sends requests to the app manager.

### src/test/java
- APIWrapperTest.java: implements the unit tests for the APIWrapper class.
- AppManagerTest.java: implements the unit tests for the AppManager class.
- DatabaseManagerTest.java: implements the unit tests for the DatabaseManager class.
