import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.*;

class DatabaseManagerTest {

    private DatabaseManager dbManager;

    DatabaseManagerTest()
    {
        dbManager = new DatabaseManager();
    }

    @Test
    public void testNewUser() throws Exception
    {
        assertTrue(dbManager.newUser("username", "password"));
        assertTrue(dbManager.validateUser("username", "password"));
    }

    @Test
    public void testAddAddress() throws Exception
    {
        dbManager.newUser("username1", "password1");
        assertTrue(dbManager.addAddress("username1", "password1", "800 W Campbell Road"));

    }

    @Test
    public void testUpdatePassword() throws Exception
    {
        dbManager.newUser("username2", "password2");
        assertTrue(dbManager.updatePassword("username2", "password2", "newpassword"));
        assertTrue(dbManager.validateUser("username2", "newpassword"));
        dbManager.updatePassword("username2", "newpassword", "password2");

    }

    @Test
    public void testValidateUser() throws Exception
    {
        dbManager.newUser("username3", "password3");
        assertTrue(dbManager.validateUser("username3", "password3"));
    }

    @Test
    public void testDeleteUser() throws Exception
    {
        Map<String, String> userInfo = new HashMap<String, String>();
        userInfo.put("username", "password");
        userInfo.put("username1", "password1");
        userInfo.put("username2", "password2");
        userInfo.put("username3", "password3");

        for(Map.Entry<String, String> userEntry : userInfo.entrySet())
        {
            if(!dbManager.validateUser(userEntry.getKey(), userEntry.getValue()))
            {
                dbManager.newUser(userEntry.getKey(), userEntry.getValue());
            }
        }

        for(Map.Entry<String, String> userEntry : userInfo.entrySet())
        {
            dbManager.deleteUser(userEntry.getKey());
            assertFalse(dbManager.validateUser(userEntry.getKey(), userEntry.getValue()));
        }

    }

    @Test
    public void testRetrieveHistoryUpdateHistory() throws Exception
    {
        dbManager.newUser("username4", "password4");
        dbManager.updateHistory("username4", "San Antonio, TX", "Italian");
        Map<String, String> history = dbManager.retrieveHistory("username4");
        assertNotNull(history);
        Map.Entry<String, String> searchItem = history.entrySet().iterator().next();
        String location = searchItem.getKey();
        String keyword = searchItem.getValue();
        assertEquals("San Antonio, TX", location);
        assertEquals("Italian", keyword);
    }

}