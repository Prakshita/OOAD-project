/**
 * Class: APIWrapperTest
 *
 * This class is designed to test the methods of the APIWrapper class which is responsible for fetching
 * data from the Google Maps APIs.
 */


import com.google.maps.model.LatLng;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class APIWrapperTest {

    private static final String CITY_1 = "Dallas, TX";
    private static final String CITY_2 = "Sydney";
    private static final LatLng CITY_1_COORDINATES = new LatLng(32.7767, -96.7970);
    private static final LatLng CITY_2_COORDINATES = new LatLng(-33.8688, 151.2093);
    private static final String API_KEY = System.getenv("GOOGLE_API_KEY");
    private static final double error = 1e-3;

    private static final String FOOD_OPTION_1 = "Pizza";
    private static final String FOOD_OPTION_2 = "Greek food";

    private APIWrapper apiWrapper = null;

    public APIWrapperTest(){

        this.apiWrapper = new APIWrapper(API_KEY);
    }

    /**
     * Tests the getCoordinates method
     * @throws Exception - throws an exception if there is an API error
     */
    @Test
    public void testGetCoordinates() throws Exception{

        LatLng dallasCoordinates = apiWrapper.getCoordinates(CITY_1)[0].geometry.location;
        LatLng sydneyCoordinates = apiWrapper.getCoordinates(CITY_2)[0].geometry.location;

        assertEquals(CITY_1_COORDINATES.lat, dallasCoordinates.lat, error);
        assertEquals(CITY_1_COORDINATES.lng, dallasCoordinates.lng, error);

        assertEquals(CITY_2_COORDINATES.lat, sydneyCoordinates.lat, error);
        assertEquals(CITY_2_COORDINATES.lng, sydneyCoordinates.lng, error);

    }

    /**
     * Tests the findRestaurants method
     * @throws Exception - throws an exception if there is an API error
     */
    @Test
    public void testFindRestaurants() throws Exception {

        Restaurant [] dallasPizzaRestaurants = apiWrapper.findRestaurants(CITY_1, FOOD_OPTION_1);
        assertNotNull(dallasPizzaRestaurants);

        Restaurant [] sydneyGreekRestaurants = apiWrapper.findRestaurants(CITY_2, FOOD_OPTION_2);
        assertNotNull(sydneyGreekRestaurants);

    }
}