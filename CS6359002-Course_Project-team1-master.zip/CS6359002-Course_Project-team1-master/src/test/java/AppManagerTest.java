import static org.junit.jupiter.api.Assertions.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

import java.util.*;

class AppManagerTest {

    private AppManager appManager;

    AppManagerTest()
    {
        this.appManager = new AppManager();
    }

    @Test
    public void testHasAPIKey() throws Exception
    {
        assertTrue(appManager.hasAPIKey());
    }

    @Test
    public void testCreateUser() throws Exception
    {
        appManager.createUser("username", "password");
        assertTrue(appManager.login("username", "password"));
    }

    @Test
    public void testDeleteUser() throws Exception
    {
        appManager.createUser("username1", "password1");
        appManager.createUser("username2", "password2");
        appManager.createUser("username3", "password3");
        appManager.deleteAccount("username1");
        appManager.deleteAccount("username2");
        appManager.deleteAccount("username3");
        assertFalse(appManager.login("username1", "password1"));
        assertFalse(appManager.login("username2", "password2"));
        assertFalse(appManager.login("username3", "password3"));
    }

    @Test
    public void testFindRestaurants()
    {
        appManager.createUser("username2", "password2");
        assertNotNull(appManager.findRestaurants("username2", "Dallas, TX", "Pizza"));
    }

    @Test
    public void testRetrieveHistory() throws Exception
    {
        appManager.createUser("username3", "password3");
        appManager.findRestaurants("username3", "Tampa, FL", "Greek");
        Map<String, String> history = appManager.retrieveHistory("username3");
        assertNotNull(history);
        Map.Entry<String, String> searchItem = history.entrySet().iterator().next();
        String location = searchItem.getKey();
        String keyword = searchItem.getValue();
        assertEquals("Tampa, FL", location);
        assertEquals("Greek", keyword);
    }

    @Test
    public void testUpdatePassword() throws Exception
    {
        appManager.createUser("username4", "password4");
        appManager.updatePassword("username4", "password4", "newPassword");
        assertFalse(appManager.login("username4", "password4"));
        assertTrue(appManager.login("username4", "newPassword"));
    }

}