/**
 * Class: RestDoorCommandLine
 * Description: Command line interface for the RestDoor Java app.
 */

import java.util.*;

public class RestDoorCommandLine {

    private AppManager appManager = new AppManager();
    private String currentUserName;
    private String currentPassword;
    private boolean loginSuccess = false;

    public void createNewUserPrompt()
    {
        /**
         * createNewUserPrompt
         * Prompts the user to create a new user and saves the user info in the database.
         **/
        boolean createUserSuccess = false;
        Scanner in = new Scanner(System.in);
        String username;
        String password;

        while(!createUserSuccess)
        {
            System.out.println("Enter your username: ");
            username = in.nextLine();
            System.out.println("Enter your password: ");
            password = in.nextLine();

            createUserSuccess = appManager.createUser(username, password);

            if(!createUserSuccess) {
                System.out.println("An error occurred, please try again!");
            }
        }
        System.out.println("User successfully created!");
    }

    public boolean successfulLogin()
    {
        return loginSuccess;
    }

    public void loginPrompt()
    {
        /**
         * loginPrompt
         * Prompts the user to login using their username and password.
         **/
        Scanner in = new Scanner(System.in);
        while(!loginSuccess) {
            System.out.println("Enter your username: ");
            currentUserName = in.nextLine();
            System.out.println("Enter your password: ");
            currentPassword = in.nextLine();

            loginSuccess = appManager.login(currentUserName, currentPassword);

            if(!loginSuccess)
            {
                System.out.println("Wrong username of password, please try again!");
            }
        }

        System.out.println("Login successful!");
    }

    public void loginOrCreateUserPrompt()
    {
        /**
         * loginOrCreateUserPrompt
         * Prompts the user to decide whether to login or create a new account
         **/

        String option;
        boolean validOption = false;
        Scanner in = new Scanner(System.in);

        System.out.println("---------------------");
        System.out.println(" Welcome to RestDoor ");
        System.out.println("---------------------");

        while(!validOption)
        {
            System.out.println("Select option from the menu below: ");
            System.out.println("[A] Create account");
            System.out.println("[B] Login");

            option = in.next();

            if (option.equalsIgnoreCase("A")) {
                validOption = true;
                createNewUserPrompt();
            } else if (option.equalsIgnoreCase("B")) {
                validOption = true;
                loginPrompt();

            } else {
                System.out.println("Invalid option.");
            }
        }

    }


    public void printRestaurants(Restaurant [] restaurants)
    {

        /**
         * printRestaurants
         *
         * Prints the information about restaurants given the list of restaurants.
         **/

        for (Restaurant restaurant: restaurants) {

            System.out.println("Restaurant Name: " + restaurant.name);
            System.out.println("Address: " + restaurant.address);
            System.out.println("Rating: " + restaurant.rating);
            System.out.println("--------------------------");
        }

    }

    public void printSearchHistory(){

        /**
         * printSearchHistory
         * Retrieves the users search history (location and keyword arguments) and prints it to the console
         */

        Map<String, String> searchHistory = appManager.retrieveHistory(currentUserName);
        System.out.println("------------------Search History-------------------------");
        for(Map.Entry<String, String> search: searchHistory.entrySet())
        {
            System.out.println("location: " + search.getKey() + ", keyword: " +  search.getValue());
        }
        System.out.println("---------------------------------------------------------");

    }

    public void printRecommendations(){

        /**
         * printRecommendations
         * Looks at the user's search history and uses it to recommend a restaurant
         */

        Map<String, String> searchHistory = appManager.retrieveHistory(currentUserName);
        Random random = new Random();
        List<String> keys = new ArrayList<String>(searchHistory.keySet());
        String location = keys.get(random.nextInt(keys.size()));
        String keyword  = searchHistory.get(location);

        Restaurant [] restaurants = appManager.findRestaurants(currentUserName, location, keyword);
        Restaurant selectedRestaurant = restaurants[random.nextInt(restaurants.length)];
        System.out.println("--------------------Recommendation---------------");
        System.out.println("Restaurant Name: " + selectedRestaurant.name);
        System.out.println("Address: " + selectedRestaurant.address);
        System.out.println("Rating: " + selectedRestaurant.rating);
        System.out.println("-------------------------------------------------");

    }

    public void updatePasswordPrompt()
    {
        /**
         * Prompts the user to enter a new password to update their password
         **/
        Scanner in = new Scanner(System.in);
        System.out.println("Enter your new password: ");
        String newPassword = in.next();
        appManager.updatePassword(currentUserName, currentPassword, newPassword);
    }

    public void addressPrompt(){

        /**
         * Prompts the user to add or update their address
         **/

        Scanner in = new Scanner(System.in);
        System.out.println("Enter your address: ");
        String address = in.nextLine();
        try
        {
            appManager.addAddress(currentUserName, currentPassword, address);
        }
        catch(Exception e1)
        {
            try {
                appManager.updateAddress(currentUserName, currentPassword, address);
            }
            catch(Exception e2)
            {
                System.out.println(e2.getStackTrace());
            }
        }
    }

    public void selectOptionPrompt(){

        /**
         * selectOptionPrompt
         * Prompts the user to select an option from the menu and performs the next steps needed to fulfill the user's requests.
         **/
        String option;
        boolean exit = false;
        Scanner in = new Scanner(System.in);

        while(!exit) {
            System.out.println("Select an option from the menu below: ");
            System.out.println("[A] Search for Restaurants");
            System.out.println("[B] View recent searches");
            System.out.println("[C] Get recommendations");
            System.out.println("[D] Add/Update Address");
            System.out.println("[E] Delete Account");
            System.out.println("[F] Change Password");
            System.out.println("[G] Quit");
            option = in.next();

            if(option.equalsIgnoreCase("A"))
            {
                searchForRestaurants();
            }
            else if(option.equalsIgnoreCase("B"))
            {
                printSearchHistory();
            }
            else if(option.equalsIgnoreCase("C"))
            {
                printRecommendations();
            }
            else if(option.equalsIgnoreCase("D"))
            {
                addressPrompt();
            }
            else if(option.equalsIgnoreCase("E"))
            {
                appManager.deleteAccount(currentUserName);
                System.exit(0);
            }
            else if(option.equalsIgnoreCase("F"))
            {
                updatePasswordPrompt();
            }
            else if(option.equalsIgnoreCase("G"))
            {
                System.out.println("Goodbye!");
                exit = true;
                System.exit(0);
            }
            else{

                System.out.println("Invalid option! Please select a valid option.");
            }
        }
    }

    public void searchForRestaurants(){

        /**
         * searchForRestaurants
         * Prompts the user for a restaurant keyword and a location and searches for restaurants
         **/

        Scanner in = new Scanner(System.in);

        System.out.println("What type of restaurants are you looking for?");
        String keyword = in.nextLine();
        System.out.println("Where are you looking for restaurants?");
        String location = in.nextLine();

        Restaurant [] restaurants = appManager.findRestaurants(currentUserName, location, keyword);

        if(restaurants != null){

            printRestaurants(restaurants);
        }
        else{

            System.out.println("An error occurred!");
        }
    }

    public static void main(String [] args)
    {
        RestDoorCommandLine commandLineInterface = new RestDoorCommandLine();
        while(!commandLineInterface.successfulLogin())
        {
            commandLineInterface.loginOrCreateUserPrompt();
        }
            commandLineInterface.selectOptionPrompt();

    }
}
