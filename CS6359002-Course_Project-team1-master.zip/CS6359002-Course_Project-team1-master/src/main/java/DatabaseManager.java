/**
 * Class: DatabaseManager
 *
 **/

import java.sql.*;
import java.util.*;
//Reference: https://www.vogella.com/tutorials/MySQLJava/article.html
//javac -cp .:/Users/tanushrisingh/Desktop/CS6359002-Course_Project-team1/src/main/java/lib/mysql-connector-java-8.0.18.jar DatabaseManager.java
//java -cp .:/Users/tanushrisingh/Desktop/CS6359002-Course_Project-team1/src/main/java/lib/mysql-connector-java-8.0.18.jar DatabaseManager

public class DatabaseManager{
    private MySQLDatabase db;

    DatabaseManager() {
        //Constructor connects to database 
        db = new MySQLDatabase();
    }

    public boolean newUser(String username, String password) {
        try {
            String query = "SELECT username FROM users WHERE users.username = ?";
            PreparedStatement preparedStmt = db.connect.prepareStatement(query);
            preparedStmt.setString(1, username);
            ResultSet res = db.fetchTables(preparedStmt);
            if (res != null) {
                query = "Insert into users (username, password)" + " values (?, ?)";
                preparedStmt = db.connect.prepareStatement(query);
                preparedStmt.setString(1, username);
                preparedStmt.setString(2, password);
                db.executeStatement(preparedStmt);
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean addAddress(String username, String password, String address) {
        try {
            String query = "UPDATE users SET address = ? WHERE users.username = ? AND users.password = ?;";
            PreparedStatement preparedStmt = db.connect.prepareStatement(query);
            preparedStmt.setString(1, address);
            preparedStmt.setString(2, username);
            preparedStmt.setString(3, password);
            db.executeStatement(preparedStmt);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateAddress(String username, String password, String address) {
        try {
            String query = "UPDATE users SET address = ? WHERE users.username = ? AND users.password = ?;";
            PreparedStatement preparedStmt = db.connect.prepareStatement(query);
            preparedStmt.setString(1, address);
            preparedStmt.setString(2, username);
            preparedStmt.setString(3, password);
            db.executeStatement(preparedStmt);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updatePassword(String username, String oldPassword, String newPassword) {
        try {
            String query = "UPDATE users SET password = ? WHERE users.username = ? AND users.password = ?;";
            PreparedStatement preparedStmt = db.connect.prepareStatement(query);
            preparedStmt.setString(1, newPassword);
            preparedStmt.setString(2, username);
            preparedStmt.setString(3, oldPassword);
            db.executeStatement(preparedStmt);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean validateUser(String username, String password) {
        try {
            String query = "SELECT users.password FROM users WHERE users.username = ?";
            PreparedStatement preparedStmt = db.connect.prepareStatement(query);
            preparedStmt.setString(1, username);
            ResultSet pass = db.fetchTables(preparedStmt);
            while (pass.next()) {
                if (pass.getString("password").equals(password)) {
                    return true;
                }
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void deleteUser(String username) {
        try {
            String query = "DELETE FROM users WHERE users.username = ?";
            PreparedStatement preparedStmt = db.connect.prepareStatement(query);
            preparedStmt.setString(1, username);
            db.executeStatement(preparedStmt);
            query = "DELETE FROM history WHERE users.username = ?";
            preparedStmt = db.connect.prepareStatement(query);
            preparedStmt.setString(1, username);
            db.executeStatement(preparedStmt);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Map<String, String> retrieveHistory(String username) {
        Map<String, String> data = new HashMap<>();
        try {
            String query = "SELECT history.location, history.keyword FROM history WHERE history.username = ?";
            PreparedStatement preparedStmt = db.connect.prepareStatement(query);
            preparedStmt.setString(1, username);
            ResultSet result = db.fetchTables(preparedStmt);
            while (result.next()) {
                data.put(result.getString("location"), result.getString("keyword"));
            }
            return data;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    public void updateHistory(String username, String location, String keyword) {

        try {
            String query = "Insert into history (username, location, keyword) values (?, ?, ?)";
            PreparedStatement preparedStmt = db.connect.prepareStatement(query);
            preparedStmt.setString(1, username);
            preparedStmt.setString(2, location);
            preparedStmt.setString(3, keyword);
            db.executeStatement(preparedStmt);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
