import java.sql.*;

public class MySQLDatabase{
    private final String myUrl = "jdbc:mysql://localhost/";
    public Connection connect;

    MySQLDatabase() {
        //Constructor connects to database 
        Statement preparedStmt = null;
        try {
            //Create database connection
            String myDriver = "com.mysql.cj.jdbc.Driver";
            Class.forName(myDriver);
            connect = DriverManager.getConnection(myUrl, "root", "rovingrook");
            preparedStmt = connect.createStatement();
            preparedStmt.executeUpdate("CREATE DATABASE IF NOT EXISTS restdoor;");
            preparedStmt.executeUpdate("USE restdoor;");
            preparedStmt.executeUpdate("CREATE TABLE IF NOT EXISTS users (username VARCHAR(20) unique not null, password VARCHAR(40) not null, address VARCHAR(100));");
            preparedStmt.executeUpdate("CREATE TABLE IF NOT EXISTS history (username VARCHAR(20) not null, location VARCHAR(40), keyword VARCHAR(40));");
        } catch (Exception e) {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }

    public void executeStatement(PreparedStatement p){
        try{
            p.execute();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    public ResultSet fetchTables(PreparedStatement p){
        ResultSet value = null;
        try{
            value = p.executeQuery();
        }catch(SQLException e){
            e.printStackTrace();
        }
        return value;
    }
}