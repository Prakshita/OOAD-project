/**
 *
 * Class: APIWrapper
 *
 * This class calls the Google Maps API to find information about restaurants.
 */


import com.google.maps.GeocodingApiRequest;
import com.google.maps.PlacesApi.*;
import com.google.maps.model.PlaceDetails;
import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.internal.ApiConfig;
import com.google.maps.model.*;
import com.google.maps.errors.*;

import java.io.IOException;
import java.lang.InterruptedException;

import com.google.maps.model.LatLng;
import com.google.maps.model.PlaceType;
import com.google.maps.model.PlacesSearchResponse;
import com.google.maps.model.PlacesSearchResult;
import com.google.maps.model.PriceLevel;
import com.google.maps.model.RankBy;
import com.google.maps.NearbySearchRequest;


public class APIWrapper {

    private String apiKey;
    private GeoApiContext context;

    /**
     * Public Constructor
     * @param apiKey - the API key with the Places and Geocoding APIs enabled.
     */
    APIWrapper(String apiKey)
    {
        this.apiKey = apiKey;
        this.context = new GeoApiContext.Builder().apiKey(apiKey).build();
    }

    /**
     *
     * @param location - a string corresponding to the location in which to search for restaurants
     * @return Returns an array of GeocodingResult objects with possible coordinates
     * @throws ApiException
     * @throws IOException
     * @throws InterruptedException
     */
    public GeocodingResult[] getCoordinates(String location) throws ApiException, IOException, InterruptedException
    {
        try {
            GeocodingResult[] results = GeocodingApi.geocode(context, location).await();
            return results;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return null;
        }
    }

    /**
     *
     * @param location - a string corresponding to the location in which to search for restaurants.
     * @param keyword - a string corresponding to the keyword used to search for restaurants
     * @return Returns a list of restaurant objects from which specific information can be retrieved.
     */
    public Restaurant [] findRestaurants(String location, String keyword)
    {
        try {

            GeocodingResult[] locationResults = getCoordinates(location);
            LatLng coordinates  = locationResults[0].geometry.location;

            NearbySearchRequest searchRequest = new NearbySearchRequest(this.context).location(coordinates).
                    radius(5000).
                    keyword(keyword);

            PlacesSearchResponse response  = searchRequest.await();
            PlacesSearchResult [] searchResults = response.results;

            Restaurant [] restaurantList = new Restaurant[searchResults.length];

            for(int i = 0; i < searchResults.length; i++) {

                PlacesSearchResult result = searchResults[i];
                restaurantList[i] = new Restaurant(result.name,
                        result.formattedAddress,
                        result.geometry.location.lat,
                        result.geometry.location.lng,
                        result.rating);

            }

            return restaurantList;

        }
        catch(Exception e){

            System.out.println(e.getMessage());
            return null;
        }

    }

}
