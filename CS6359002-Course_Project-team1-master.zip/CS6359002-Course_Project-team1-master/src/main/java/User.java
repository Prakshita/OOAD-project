public class User {

    private String username;
    private String password;
    private String address = null;
    private boolean loggedIn = false;

    User(String username, String password)
    {
        this.username = username;
        this.password = password;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public String getUsername()
    {
        return this.username;
    }

    public void changePassword(String oldPassword, String newPassword)
    {
        this.password = newPassword;
    }

    public boolean login(String inputPassword)
    {
        if(inputPassword == this.password)
        {
            loggedIn = true;
        }
        else{
            loggedIn = false;
        }

        return loggedIn;
    }
}
