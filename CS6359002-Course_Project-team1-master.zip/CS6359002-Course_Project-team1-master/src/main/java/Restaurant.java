/**
 * Class: Restaurant
 * A simple class representing a restaurant with identifying information.
 */
public class Restaurant {

    String name;
    String address;
    float rating;
    double latitude;
    double longitude;

    public Restaurant(String name, String address){

        this.name = name;
        this.address = address;
    }

    public Restaurant(String name, String address, double latitude, double longitude, float rating){

        this.name = name;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
        this.rating = rating;
    }

}
