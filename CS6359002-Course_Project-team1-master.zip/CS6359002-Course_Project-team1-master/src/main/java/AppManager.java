/**
 * Class: AppManager
 * Description: Handles requests from the command line app and interacts directly with the database manager and the API wrapper.
 **/

import java.io.IOException;
import java.util.*;

public class AppManager{

    private APIWrapper apiWrapper;
    private boolean apiKeyExists = false;
    private DatabaseManager dbManager;
    private HashMap<String, User> userCache;

    AppManager(String apiKey){
        /**
         *  Constructor
         *  Creates an APIWrapper object using an API key as input.
         **/

        apiWrapper = new APIWrapper(apiKey);
        apiKeyExists = true;
        dbManager = new DatabaseManager();
        userCache = new HashMap<String, User>();
    }

    AppManager(){

        /**
         * Default constructor
         **/

        String apiKey = System.getenv("GOOGLE_API_KEY");
        setAPIKey(apiKey);
        dbManager = new DatabaseManager();
        userCache = new HashMap<String, User>();
    }

    public void setAPIKey(String apiKey)
    {
        /**
         * Sets the API Key given a string input
         **/
        if(apiKey != null) {
            apiWrapper = new APIWrapper(apiKey);
            apiKeyExists = true;
        }
    }

    public boolean hasAPIKey(){

        /**
         * Returns true if the API Key was set and false otherwise.
         **/

        return apiKeyExists;
    }


    public Restaurant [] findRestaurants(String username,  String location, String keyword){

        /**
         * Finds a list of restaurants given a location and keyword.
         **/

        dbManager.updateHistory(username, location, keyword);
        return apiWrapper.findRestaurants(location, keyword);
    }

    public boolean createUser(String username, String password)
    {
        /**
         * Requests the database manager to add a new user.
         **/
        userCache.put(username, new User(username, password));
        return dbManager.newUser(username, password);
    }

    public User findUserInCache(String username)
    {
        return userCache.get(username);
    }

    public void deleteUserFromCache(String username)
    {

        userCache.remove(username);
    }

    public boolean loginUserFromCache(String username, String password)
    {
        User user = findUserInCache(username);

        if(user != null) {

            boolean loginSuccess = user.login(password);
            userCache.replace(username, user);
            return loginSuccess;
        }
        else{

            return false;
        }
    }

    public boolean login(String username, String password)
    {
        //Logic for logging in user goes here
        /**
         * Validates a login request using the database manager.
         **/
        if(loginUserFromCache(username, password))
        {
            return true;
        }
        else
        {
            boolean loginSuccess = dbManager.validateUser(username, password);
            if(loginSuccess)
            {
                User currentUser = new User(username, password);
                currentUser.login(password);
                userCache.put(username, currentUser);

            }

            return loginSuccess;
        }
    }

    public void deleteAccount(String username)
    {
        /**
         * Deletes a user's account from the database using the database manager
         **/
        deleteUserFromCache(username);
        dbManager.deleteUser(username);
    }

    public boolean addAddress(String username, String password, String address)
    {
        /**
         * Adds the user's address entry using the database manager.
         **/
        User user = userCache.get(username);
        user.setAddress(address);
        userCache.replace(username, user);
        return dbManager.addAddress(username, password, address);
    }

    public boolean updateAddress(String username, String password, String address)
    {
        /**
         * Updates the user's address using the database manager.
         **/
        User user = userCache.get(username);
        user.setAddress(address);
        userCache.replace(username, user);
        return dbManager.updateAddress(username, password, address);
    }

    public boolean updatePassword(String username, String oldPassword, String newPassword)
    {
        /**
         * Requests the database manager to update the user's password
         **/
        User user = userCache.get(username);
        user.changePassword(oldPassword, newPassword);
        userCache.replace(username, user);
        return dbManager.updatePassword(username, oldPassword, newPassword);
    }

    public Map<String, String> retrieveHistory(String username)
    {
        /**
         * Requests the database manager to return the user's search history.
         **/

        return dbManager.retrieveHistory(username);
    }

}